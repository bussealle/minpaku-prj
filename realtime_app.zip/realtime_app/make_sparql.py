from SPARQLWrapper import SPARQLWrapper

def get_dbpedia(sub,pre,obj):
    sparql = SPARQLWrapper(endpoint='http://ja.dbpedia.org/sparql', returnFormat='json')
    query = """
        PREFIX dbp-owl: <http://dbpedia.org/ontology/>
        PREFIX dbpj: <http://ja.dbpedia.org/resource/>
    """
    if sub[0]=='?':
        query = query + f"    SELECT {sub} WHERE "
    elif obj[0]=='?':
        query = query + f"    SELECT {obj} WHERE "
    elif pre[0]=='?':
        query = query + f"    SELECT {pre} WHERE "
    else:
        return None
    query = query + "{"+f" {sub} {pre} {obj} . "+"}"
    sparql.setQuery(query)
    results = sparql.query().convert()
    try:
        result = results['results']['bindings']
        return result
    except:
        return None

def test_query():
    query = """
        PREFIX dbp-owl: <http://dbpedia.org/ontology/>
        PREFIX dbpj: <http://ja.dbpedia.org/resource/>
        PREFIX dbr: <http://dbpedia.org/resource>
        SELECT ?o WHERE {
            {
                dbr:検索語（英語） rdf:type ?o .
                FILTER regex( ?o, “http://dbpedia.org/ontology/”)
            } UNION
            {
                dbr:検索語（英語） dct:subject ?o .
                FILTER regex(?o, “http://dbpedia.org/resource/Category”)
            }
        }
    """
    sparql.setQuery(query)
    results = sparql.query().convert()
    return(results)

if __name__ == '__main__':
    print(test_query())
    # results = get_dbpedia(sub='dbpj:祭', pre='dbp-owl:wikiPageWikiLink',obj='?re')
    # #results2 = get_dbpedia(sub='dbpj:祭', pre='dbpedia-owl:wikiPageID',obj='?re')
    # print(results)
    # #print(results2)
    # if results:
    #     for result in results:
    #         print(result)
    # else:
    #     print('error')
