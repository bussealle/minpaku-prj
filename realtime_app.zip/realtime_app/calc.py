import pymongo
import sys
import copy
import json
import pytz
from datetime import datetime
from make_sparql import get_dbpedia
from make_mecab import parse_on_mecab
import re
import MeCab
import plotly
import threading
from original_func import remove_parenthesis,make_touple
from concurrent.futures import ThreadPoolExecutor

# Initizlize MongoDB
client = pymongo.MongoClient('localhost',27017)
db = client['minpaku']
#co_full = db['mofull']
co_cat = db['mocat']
co_cache = db['cache']

# JSON Files
beacons_name = 'beacons.json'
with open(beacons_name,'r') as br:
    beacons_js = json.load(br)
jst = pytz.timezone('Asia/Tokyo')
###print(datetime.fromtimestamp(int(logs[10]['time'])).astimezone(jst)-datetime.fromtimestamp(int(logs[9]['time'])).astimezone(jst))

# Regex
name_re = r'^(\S+)\s{0,1}(\S+){0,1}＜\S+＞.*$'
name_re = re.compile(name_re)

# Parameters
UUID = "5acf2bbbb7221801b3da001c4d3514ae"
thread_key = ["tag",'country',"region","received",'race',"OCM",'OWC']


# SEARCH ON MONGODB
def search_on_mongo(beacon_num,beacons_js):
    b_num = str(beacon_num)
    beacon = beacons_js.get(b_num)
    result = []
    if not beacon:
        return result
    ids = beacon['ids']
    for target_id in ids:
        obj = co_cat.find_one({"id" : target_id})
        if obj:
            result.append(obj)
    return result

# CALCULATE RELATIVE SCORE
def calc_single_score(objs,prox,sw=True):

    result = {}
    combined = []
    completed = []
    new_combined = []

    def proximity_weight(proximity):
        weight = 1.0 #0.0~1.0
        return 1/(proximity*weight)

    def thread_dbpedia(tag):
        tag_find = co_cache.find_one({"original_tag" : tag['data']})
        if tag_find:
            fixed_tag = tag_find.get("fixed_tag")
            if fixed_tag:
                tag['data'] = fixed_tag
                new_combined.append(tag)
        elif tag['data'] and not tag['data'] in completed:
            tag_temp = 'dbpj:' + tag['data']
            fixed_tags = get_dbpedia(sub=tag_temp,pre='dbp-owl:wikiPageRedirects',obj='?val')
            if fixed_tags:
                new_tag = fixed_tags[0]['val']['value'].split('/')[-1]
                ##print("\t|\t"+tag+' → '+new_tag+f"  ({fixed_tags[0]['val']['value']})")
                completed.append(tag['data'])
                co_cache.insert({"original_tag" : tag['data'], "fixed_tag" : new_tag})
                for t in combined:
                    if t['data']==tag['data']:
                        new_combined.append({'data':new_tag,'id':t['id']})
            else:
                found_dbpedia = get_dbpedia(sub=tag_temp,pre='dbpedia-owl:wikiPageID',obj='?re')
                insert_data = {}
                insert_data["original_tag"] = tag['data']
                if not found_dbpedia:
                    tag['data'] = tag['data']+'*'
                insert_data["fixed_tag"] = tag['data']
                new_combined.append(tag)
                co_cache.insert(insert_data)

    for obj in objs:
        if not obj:
            continue
        if type(obj)!=list:
            obj = [obj]
        combined = combined + obj
    total = len(combined)
    if sw:
        with ThreadPoolExecutor(max_workers=10) as executor:
            executor.map(thread_dbpedia,combined)
        combined = new_combined
        completed = []
    combined_list = [x['data'] for x in combined]
    for r in combined:
        tag_name = r['data']
        if tag_name in completed:
            continue
        tag_cnt = combined_list.count(tag_name)
        ids = list(set([x['id'] for x in combined if x['data']==tag_name]))
        result[tag_name] = {'data':tag_cnt/total*proximity_weight(prox),'id': ids}
        completed.append(tag_name)
    return result

def calc_multiple_score(scores,proximity):

    if len(scores)==1:
        return scores[0]
    prox_sum = sum([x for x in proximity])
    prox_ratio = [1/(x/prox_sum) for x in proximity]
    prox_sum = sum(prox_ratio)
    prox_ratio = [x/prox_sum for x in prox_ratio]
    ###print(proximity)
    ###print(prox_ratio)
    new_score = {}
    for key in scores[0].keys():
        new_score[key] = {}
    for key in new_score.keys():
        visited = []
        for i in range(len(scores)):
            score = scores[i]
            if not score:
                continue
            score_tag = score[key]
            new_score_tag = new_score[key]
            for tag in score_tag.keys():
                if tag in visited:
                    continue
                new_score_tag[tag] = {'data':None,'id':None}
                new_score_tag[tag]['data'] = score_tag[tag]['data'] * prox_ratio[i]
                new_score_tag[tag]['id'] = score_tag[tag]['id']
                for j in range(i+1,len(scores)):
                    temp = scores[j][key].get(tag)
                    if temp:
                        new_score_tag[tag]['id'] += temp['id']
                        new_score_tag[tag]['data'] += temp['data'] * prox_ratio[j]
                visited.append(tag)
    return new_score

def calc_score(posted_json):
    # Log
    if not type(posted_json) is list:
        logs = [posted_json]
    # Vars
    all_scores = []
    cnt = 0
    cnt_before = 0
    cnt_all = len(logs)
    cnt_found = 0
    cnt_notfound = 0

    for log in logs:
        # if cnt>10:
        #     continue
        # cnt+=1
        data = log['data']
        time = log['time']
        #time_text = datetime.fromtimestamp(int(time)).astimezone(jst).strftime('%Y-%m-%d %H:%M:%S')
        ds = data.get(UUID)
        if ds :
            new_ds = []
            for i in range(len(ds)):
                d = ds[i]
                minor = d['minor']
                if minor in [x['minor'] for x in new_ds]:
                    continue
                temp = [x for x in ds if x['minor']==minor]
                new_rssi = sum([x['rssi'][0] for x in temp])/len(temp)
                new_txp = sum([x['txp'][0] for x in temp])/len(temp)
                d['rssi'][0] = new_rssi
                d['txp'][0] = new_txp
                new_ds.append(d)
            vec_rssi = [d['rssi'][0] for d in new_ds]
            vec_txp = [d['txp'][0] for d in new_ds]
            vec_minor = [d['minor'] for d in new_ds]
            vec_radius = [pow(10, (d['txp'][0] - d['rssi'][0]) / 20) for d in new_ds]

            # if cnt!=0:
            #     continue
            # if len(vec_minor)==1 and vec_minor[0]==1:
            #     cnt+=1
            # if (len(vec_minor)==4):
            #     cnt+=1
            # else:
            #     continue

            ##print('')
            ##print(f"{time_text}----------------------------------------------------------------------")
            ##print("【DETECTED BEACONS】")
            detected_scores = []
            for i in range(len(vec_minor)):
                ##print(f"\tMinor:\t{vec_minor[i]}")
                ##print(f"\t|\tRSSI     \t:\t{vec_rssi[i]}")
                ##print(f"\t|\tTxPower  \t:\t{vec_txp[i]}")
                ##print(f"\t|\tProximity\t:\t{vec_radius[i]}")
                ##############
                prox = vec_radius[i]
                b_result = {"tag":[],"country":[],"region":[],"received":[],"race":[],"OCM":[],"OWC":[]}
                objs = search_on_mongo(beacon_num=vec_minor[i],beacons_js=beacons_js)
                if len(objs)==0:
                    detected_scores.append(None)
                else:
                    ##print("\t|")
                    ##print("\t【EXHIBIT INFOMATION】------->")
                    for obj in objs:
                        id = obj.get('id')
                        imageurls = obj.get('imageurls')
                        name = obj.get('name')
                        region = obj.get('region')
                        race = obj.get('race')
                        received = obj.get('received_in')
                        ocm = obj.get('OCM')
                        owc = obj.get('OWC')
                        country = None
                        name = name.split('\n')
                        tags = parse_on_mecab(name[0])
                        for i in range(len(tags)):
                            tags[i] = {'data':tags[i], 'id':id}
                        ##print(f"\t|\tid         :\t{obj.get('id')}")
                        ##print(f"\t|\tname       :\t{name[0]}")
                        ##print(f"\t|\ttags       :\t{tags}")
                        ##############
                        if ocm:
                            ocm = ocm.split(', ')
                            for i in range(len(ocm)):
                                ocm[i] = {'data':ocm[i], 'id':id}
                        if owc:
                            owc = owc.split(', ')
                            for i in range(len(owc)):
                                owc[i] = {'data':owc[i], 'id':id}
                        if race:
                            race = race.split('；')[0]
                        if region:
                            match = name_re.match(remove_parenthesis(region))
                            if match:
                                country = match[1]
                                try:
                                    region = match[2]
                                except:
                                    None
                            else:
                                print("region error: "+region)
                        ##print(f"\t|\tcountry    :\t{country}")
                        ##print(f"\t|\tregion     :\t{region}")
                        ##print(f"\t|\trace       :\t{race}")
                        ##print(f"\t|\treceived_in:\t{received}")
                        ###print(f"\timages:\t{imageurls}")
                        ##print("\t|")
                        b_result['tag'].append(tags)
                        if not country:
                            b_result['country'].append({'data':country, 'id':id})
                        if not region:
                            b_result['region'].append({'data':region, 'id':id})
                        if not race:
                            b_result['race'].append({'data':race, 'id':id})
                        if not received:
                            b_result['received'].append({'data':received, 'id':id})
                        b_result['OCM'].append(ocm)
                        b_result['OWC'].append(owc)
                    ##print("\t【DBPEDIA TAG FIXING】------->")
                    thread_tags = [b_result[x] for x in thread_key]
                    thread_prox = [prox] * len(thread_key)
                    thread_sw = [True]*3+[False]*4
                    with ThreadPoolExecutor(max_workers=10) as executor:
                        thread_result = executor.map(calc_single_score,thread_tags,thread_prox,thread_sw)
                        thread_result = list(thread_result)
                    for i in range(len(thread_result)):
                        b_result[thread_key[i]] = thread_result[i]
                    detected_scores.append(b_result)
                    ##print("\t【SINGLE ABSTRACTION SCORE】------->")
                    ##print(f"\t|\t{b_result}")
                    ##print('\n\n')
            new_score = calc_multiple_score(detected_scores,vec_radius)
            ##print("【MULTIPLE ABSTRACTION SCORE】------->")
            ##print(f"\t{new_score}")
            all_scores.append(new_score)
            ##print(sorted(new_score['tag'].items(), key=lambda x: x[1],reverse=True))
            ##print('--------------------------------------------------------------------------------')
            ##print('\n')
            # percent = cnt/cnt_all*100
            # if (percent-cnt_before) > 1.0:
            #     print(f"{cnt} frame --- {percent}%")
            # cnt_before = percent

    log_calc = None
    try:
        with open('log_calc.json','r') as f :
            log_calc = json.load(f)
    except:
        None
    result = log_calc

    if not type(result) is dict:
        result = {}
        for key in thread_key:
            result[key] = {}
    for s in all_scores:
        for key in s.keys():
            for k in s[key].keys():
                find = result[key].get(k)
                if find:
                    result[key][k]['data'] += s[key][k]['data']
                    for i in s[key][k]['id']:
                        if not i in result[key][k]['id']:
                            result[key][k]['id'].append(i)
                else:
                    result[key][k] = {'data':None,'id':None}
                    result[key][k]['data'] = s[key][k]['data']
                    result[key][k]['id'] = s[key][k]['id']

    # tag_find_cnt = 0
    # for key in result['tag'].keys():
    #     if key.find('*')!=-1:
    #         remove_parenthesis(region)
    #         tag_find_cnt += 1

    with open('log_calc.json','w') as of:
            json.dump(result,of,indent=4)
